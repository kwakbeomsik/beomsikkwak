import random

from pico2d import *




class Main_Character:


    PIXEL_PER_METER = (10.0 / 5000)  # 10 pixel 30 cm
    RUN_SPEED_KMPH = 20.0  # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 500
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 500


    image = None
    eat_sound = None
    hit_sound = None

    STAND_RIGHT, STAND_LEFT, MOVE_RIGHT, MOVE_LEFT, JUMP_RIGHT, JUMP_LEFT, HIT_RIGHT, HIT_LEFT = 0, 1, 2, 3, 4, 5, 6, 7

    def __init__(self):

        self.frame = random.randint(0, 7)
        self.life_time = 0.0
        self.total_frames = 0.0
        self.dir = 0
        self.state = self.STAND_RIGHT
        if Main_Character.image == None:
            Main_Character.image = load_image('resource/character/character_main_zoro1.png')

            self.x, self.y = 0, 120

        self.frame = 0
        self.state = self.STAND_RIGHT
        if Main_Character.eat_sound == None:
            Main_Character.eat_sound = load_wav('pang.wav')
            Main_Character.eat_sound.set_volume(32)
        elif Main_Character.hit_sound == None:
            Main_Character.hit_sound = load_wav('scream.wav')
            Main_Character.hit_sound.set_volume(25)



    def update(self, frame_time):
        global count
        count = 0

        if self.state == self.MOVE_RIGHT:
            if self.x < 2400:
               self.x += 3
            else:
               self.x += 0

        if self.state == self.MOVE_LEFT:
            if self.x > 30:
               self.x -= 3
            else:
                self.x -= 0
        if self.state == self.JUMP_RIGHT or self.state == self.JUMP_LEFT :
            count += 1
            if count < 10:
                self.y += 1
            elif count >= 10:
                self.y -= 1
            elif count == 20:
                count = 0



        if self.state == self.MOVE_RIGHT or self.state == self.MOVE_LEFT or self.state == self.HIT_LEFT or self.state == self.HIT_RIGHT:
                self.state_frame = 6
        elif self.state == self.STAND_RIGHT or self.state == self.STAND_LEFT:
                self.state_frame = 1
        elif self.state == self.JUMP_RIGHT or self.state == self.JUMP_LEFT:
                self.state_frame = 8


        self.frame = (self.frame + 1) % self.state_frame

        if self.state != self.HIT_RIGHT and self.state != self.HIT_LEFT and \
                            self.state != self.MOVE_RIGHT and self.state != self.MOVE_LEFT and self.state != self.STAND_LEFT:
            if self.frame == 0:
                    self.state = self.STAND_RIGHT

    def eat(self, ball):
        self.eat_sound.play()

        pass

    def hit(self, ball):
        self.hit_sound.play()

        pass

    def draw(self):
        # 케릭터 정지
        if self.state == self.STAND_RIGHT:
            self.image.clip_draw(self.frame * 162, 122, 162, 133, 300 + self.x, self.y)
        elif self.state == self.STAND_LEFT:
            self.image.clip_draw(self.frame * 162, 0, 162, 133, 300 + self.x, self.y)
        # 케릭터 좌/우 이동
        elif self.state == self.MOVE_RIGHT:
            self.image.clip_draw(self.frame * 162, 1320, 162, 133, 300 + self.x, self.y)
        elif self.state == self.MOVE_LEFT:
            self.image.clip_draw(self.frame * 160, 1170, 158, 140, 300 + self.x, self.y)
        # 케릭터 공격
        elif self.state == self.HIT_RIGHT:
            self.image.clip_draw(self.frame * 232, 550, 210, 185, 300 + self.x, self.y)
        elif self.state == self.HIT_LEFT:
            self.image.clip_draw(self.frame * 230, 300, 170, 190, 300 + self.x, self.y)
        # 케릭터 점프
        elif self.state == self.JUMP_RIGHT:
            self.image.clip_draw(self.frame * 170, 960, 150, 205, 300 + self.x, self.y + 60)
        elif self.state == self.JUMP_LEFT:
            self.image.clip_draw(self.frame * 170, 755, 180, 205, 300 + self.x, self.y + 60)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        if self.state == self.HIT_LEFT or self.state == self.HIT_RIGHT:
            return self.x + 215 , self.y - 75, self.x + 400, self.y + 75
        else:
            return self.x + 235, self.y - 75, self.x + 370, self.y + 75

    def handle_event(self, event):
        global running
        # events = get_events()
        # for event in events:
        #     if event.type == SDL_QUIT:
        #         running = False
        #     elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
        #         running = False
        if (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT) or (event.type, event.key) == (SDL_KEYUP, SDLK_d) or (
        event.type, event.key) == (SDL_KEYUP, SDLK_s):
            self.state = self.STAND_RIGHT

        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT) or (event.type, event.key) == (SDL_KEYUP, SDLK_d) or (
        event.type, event.key) == (SDL_KEYUP, SDLK_s):
            self.state = self.STAND_LEFT

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            self.state = self.MOVE_RIGHT
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            self.state = self.MOVE_LEFT
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_d) and self.state == self.STAND_RIGHT:
            self.state = self.HIT_RIGHT
            self.frame = 0

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_d) and self.state == self.STAND_LEFT:
            self.state = self.HIT_LEFT
            self.frame = 0

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_s) and self.state == self.STAND_RIGHT:
            self.state = self.JUMP_RIGHT
            self.frame = 0

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_s) and self.state == self.STAND_LEFT:
            self.state = self.JUMP_LEFT
            self.frame = 0




