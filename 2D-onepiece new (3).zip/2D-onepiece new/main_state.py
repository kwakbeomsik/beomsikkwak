from pico2d import *

import game_framework
import title_state


from main_character import Main_Character
from enemy import Enemy
from enemy import Enemy1
from enemy import Ball
from boss import Boss
from background import BackGround



name = "main_state"

font  = None
hero = None
back = None
enemys = None
enemys1 = None
balls = None
boss1 = None
life = 10


def create_world():
    global hero, back, enemys, enemys1, balls, font, boss1

    font = load_font('ENCR10B.TTF')
    hero = Main_Character()
    back = BackGround(1235,600)
    enemys = Enemy()
    enemys1= Enemy1()
    boss1 = Boss()
    balls = [Ball() for i in range(25)]




def destroy_world():
    global hero, boss1,  back, enemys, enemys1, balls

    del(hero)
    del(back)
    del(enemys)
    del (enemys1)
    del (balls)
    del (boss1)



def enter():
    open_canvas(1235,600)
    hide_cursor()
    game_framework.reset_time()
    create_world()


def exit():
    destroy_world()
    close_canvas()


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                game_framework.quit()
            else:
                hero.handle_event(event)
                back.handle_event(event)



def collide(a, b):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = b.get_bb()

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a < bottom_b: return False
    if bottom_a > top_b: return False

    return True


def update(frame_time):
    global life
    back.update(frame_time)
    hero.update(frame_time)
    enemys.update(frame_time)
    enemys1.update(frame_time)
    boss1.update(frame_time)

    for enemy in balls:
        enemy.update(frame_time)
    for enemy in balls:
        if collide(hero, enemy):
            if hero.state == hero.HIT_LEFT or hero.state == hero.HIT_RIGHT:
               balls.remove(enemy)
               hero.eat(enemy)
            else:
                hero.x -= 70
                hero.eat(enemy)
                life -= 1

    if collide(hero, enemys):
        print("collide!!")
    if life == 0:
        close_canvas()

def draw(frame_time):


    clear_canvas()
    back.draw()
    hero.draw()
    enemys.draw()
    enemys1.draw()

    boss1.draw()
    font.draw(0, 500, 'LIFE = %3d ' % life, (255, 255, 255))

    for enemy in balls:
        enemy.draw()


    enemys.draw_bb()
    enemys1.draw_bb()

    hero.draw_bb()
    for enemy in balls:
        enemy.draw_bb()

    boss1.draw()
    boss1.draw_bb()
    update_canvas()






