import random

from pico2d import *
from main_character import Main_Character

class Enemy:

    image = None
    MOVE = 0

    def __init__(self):
        self.x, self.y = random.randint(500, 1700), 130
        if Enemy.image == None:
            Enemy.image = load_image('resource/enemy/enemy1.png')
            self.frame = 0
            self.state = self.MOVE

    def update(self, frame_time):
        self.x -= 0.3
        self.frame = (self.frame + 1) % 8

    def draw(self):
        if self.state == self.MOVE:
            self.image.clip_draw(self.frame * 121, 468, 121, 100, 300 + self.x, self.y)

    def get_bb(self):
        return self.x + 250, self.y - 70, self.x + 345, self.y + 70

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

class Enemy1:

    image = None
    MOVE = 3

    def __init__(self):
        self.x, self.y = random.randint(200, 790), 130
        if Enemy1.image == None:
            Enemy1.image = load_image('resource/enemy/enemy1.png')
            self.frame = 0
            self.state = self.MOVE

    def update(self, frame_time):
            self.x -= 0.3
            self.frame = (self.frame + 1) % 8

    def draw(self):
        if self.state == self.MOVE:
            self.image.clip_draw(self.frame * 121, 468, 121, 100, 300 + self.x, self.y)

    def get_bb(self):
        return self.x + 250, self.y - 70, self.x + 345, self.y + 70

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

class Ball:

    image = None;

    def __init__(self):
        self.x, self.y = random.randint(200, 2500), 120
        if Ball.image == None:
            Ball.image = load_image('resource/enemy/obstacle.png')

    def update(self, frame_time):
        self.x -= 1
        pass

    def draw(self):
        self.image.draw(self.x, self.y)

    # fill here
    def get_bb(self):
        return  self.x - 25, self.y - 25, self.x + 25, self.y + 25

    def draw_bb(self):
        draw_rectangle(*self.get_bb())





