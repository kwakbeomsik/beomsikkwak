import random

import random

from pico2d import *
from main_character import Main_Character
global count


class Boss:

    image = None;

    def __init__(self):
        self.x, self.y = 1200, 200
        if Boss.image == None:
            Boss.image = load_image('resource/enemy/boss.png')

    def update(self, frame_time):
        self.x -= 0.1
        pass

    def draw(self):
        self.image.draw(self.x, self.y)

    # fill here
    def get_bb(self):
        count  = 0
        if count == 0:
            count += 1
            if count < 30:
               return  self.x - 190, self.y - 230, self.x + 220, self.y + 230
            elif count >= 30:
               return self.x - 220, self.y - 230, self.x + 220, self.y + 230
    def draw_bb(self):
        draw_rectangle(*self.get_bb())
